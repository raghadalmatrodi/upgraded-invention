import java.util.*;
public class mobileCalls{
static Scanner read=new Scanner(System.in);
public static void main(String[]args){
System.out.println("Enter 1 or 2 to choose the bill:"); 
System.out.println("1.The call price for postpaid customers.");
System.out.println("2.The call price for prepaid customers.");
int choice=read.nextInt();

if (choice==1)
{System.out.println("Enter the code: R or S");
char c=read.next().charAt(0);
System.out.print("Enter number of mins>>"); 
int min=read.nextInt();
CallPrice(min,c);
System.out.printf("The Due amount for this customer is %.2f",CallPrice(min,c));}

if(choice==2)
{System.out.print("Enter number of mins>>");
int min=read.nextInt();
System.out.print("Enter charge amount already you have>>");
double chargAmount=read.nextDouble();
CallPrice(min,chargAmount);
System.out.printf("The new balance for this customer is %.2f ",CallPrice(min,chargAmount) );}
 
if (choice!=1&&choice!=2) 
System.out.println("Invalid input");}

public static double CallPrice(int min, char c){
double price=0;
if (c=='R'||c=='r')
price=min*0.99;
if (c=='S'||c=='s')
price=min*0.50;
return price;}

public static double CallPrice(int min,double chargAmount) {
double price=0;
if (min<=5)
price=chargAmount-(min*1);
if (min>5)
price=chargAmount-(((min-5)*1.50)+5);
return price;}
}